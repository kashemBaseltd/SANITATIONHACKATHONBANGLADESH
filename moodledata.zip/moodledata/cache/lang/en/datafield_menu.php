<?php $this->cache['en']['datafield_menu'] = array (
  'pluginname' => 'Menu',
);