<?php $this->cache['en']['filter_emailprotect'] = array (
  'filtername' => 'Email protection',
);