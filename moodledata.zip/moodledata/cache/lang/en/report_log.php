<?php $this->cache['en']['report_log'] = array (
  'log:view' => 'View course logs',
  'log:viewtoday' => 'View today\'s logs',
  'logsformat' => 'Logs format',
  'page-report-log-x' => 'Any log report',
  'page-report-log-index' => 'Course log report',
  'page-report-log-user' => 'User course log report',
  'pluginname' => 'Logs',
);