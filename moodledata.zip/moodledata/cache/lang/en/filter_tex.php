<?php $this->cache['en']['filter_tex'] = array (
  'filtername' => 'TeX notation',
  'source' => 'TeX source',
);