<?php $this->cache['en']['quizaccess_password'] = array (
  'passworderror' => 'The password entered was incorrect',
  'pluginname' => 'Password quiz access rule',
  'quizpassword' => 'Quiz password',
  'requirepasswordmessage' => 'To attempt this quiz you need to know the quiz password',
);