<?php $this->cache['en']['datafield_multimenu'] = array (
  'pluginname' => 'Multimenu',
);