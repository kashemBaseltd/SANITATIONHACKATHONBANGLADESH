<?php $this->cache['en']['theme_standard'] = array (
  'pluginname' => 'Standard',
  'region-side-post' => 'Right',
  'region-side-pre' => 'Left',
  'choosereadme' => 'This theme is a very basic white theme, with a minimum amount of CSS added to the base theme to make it actually usable.',
);