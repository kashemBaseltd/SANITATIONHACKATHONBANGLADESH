<?php $this->cache['en']['auth_nologin'] = array (
  'auth_nologindescription' => 'Auxiliary plugin that prevents user to login into system and also discards any mail sent to the user. Can be used to <em>suspend</em> user accounts.',
  'pluginname' => 'No login',
);