<?php $this->cache['en']['datafield_latlong'] = array (
  'pluginname' => 'Latlong',
);