<?php $this->cache['en']['quizaccess_delaybetweenattempts'] = array (
  'pluginname' => 'Delay between attempts quiz access rule',
  'youcannotwait' => 'This quiz closes before you will be allowed to start another attempt.',
  'youmustwait' => 'You must wait before you may re-attempt this quiz. You will be allowed to start another attempt after {$a}.',
);