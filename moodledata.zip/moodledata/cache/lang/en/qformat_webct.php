<?php $this->cache['en']['qformat_webct'] = array (
  'errorsdetected' => '{$a} error(s) detected',
  'missinganswer' => 'Too few :ANSWER, :Lx, :Rx statements for question line {$a}. You must define at last 2 possible answers',
  'missingquestion' => 'Missing question label after line {$a}',
  'paragraphquestion' => 'Paragraph question',
  'pluginname' => 'WebCT format',
  'pluginname_help' => 'WebCT format enables multiple-choice and short answer questions saved in WebCT\'s text-based format to be imported.',
  'pluginname_link' => 'qformat/webct',
  'questionnametoolong' => 'Question name too long at line {$a} (255 char. max). It has been truncated.',
  'unknowntype' => 'Unknown type',
  'warningsdetected' => '{$a} warning(s) detected',
  'wronggrade' => 'Wrong grade (after line {$a}) :',
);