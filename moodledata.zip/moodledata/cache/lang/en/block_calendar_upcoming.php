<?php $this->cache['en']['block_calendar_upcoming'] = array (
  'pluginname' => 'Upcoming events',
);