<?php $this->cache['en']['quizaccess_openclosedate'] = array (
  'notavailable' => 'This quiz is not currently available',
  'pluginname' => 'Open and close date access rule',
  'quiznotavailable' => 'The quiz will not be available until {$a}',
);