<?php $this->cache['en']['block_social_activities'] = array (
  'pluginname' => 'Social activities',
);