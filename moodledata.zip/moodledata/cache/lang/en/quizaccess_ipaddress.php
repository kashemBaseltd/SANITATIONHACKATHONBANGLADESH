<?php $this->cache['en']['quizaccess_ipaddress'] = array (
  'pluginname' => 'IP address quiz access rule',
  'subnetwrong' => 'This quiz is only accessible from certain locations, and this computer is not on the allowed list.',
);