<?php $this->cache['en']['scormreport_graphs'] = array (
  'participants' => 'Number of participants',
  'pluginname' => 'Graph report',
  'percent' => 'Percent(%) secured',
  'invaliddata' => 'Not enough data',
);