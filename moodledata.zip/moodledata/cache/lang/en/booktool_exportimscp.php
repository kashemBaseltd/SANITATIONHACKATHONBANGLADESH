<?php $this->cache['en']['booktool_exportimscp'] = array (
  'exportimscp:export' => 'Export book as IMS content package',
  'generateimscp' => 'Generate IMS CP',
  'nochapters' => 'No book chapters found, so unable to export to IMS CP.',
  'pluginname' => 'Book IMS CP export',
);