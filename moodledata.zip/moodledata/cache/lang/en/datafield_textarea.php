<?php $this->cache['en']['datafield_textarea'] = array (
  'maxbytes' => 'Maximum embedded file size (bytes)',
  'maxbytes_desc' => 'If set to zero will be unlimited by default',
  'pluginname' => 'Text area',
);