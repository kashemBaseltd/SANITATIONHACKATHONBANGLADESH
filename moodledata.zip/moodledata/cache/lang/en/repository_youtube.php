<?php $this->cache['en']['repository_youtube'] = array (
  'pluginname' => 'Youtube videos',
  'search' => 'Search videos',
  'youtube:view' => 'Use youtube in file picker',
  'configplugin' => 'YouTube repository type configuration',
  'sortby' => 'Sort By',
  'sortpublished' => 'Date Published',
  'sortrating' => 'Rating',
  'sortrelevance' => 'Relevance',
  'sortviewcount' => 'View Count',
);