<?php $this->cache['en']['gradeimport_csv'] = array (
  'csv:view' => 'Import grades from CSV',
  'pluginname' => 'CSV file',
);