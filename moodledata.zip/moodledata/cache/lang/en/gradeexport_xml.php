<?php $this->cache['en']['gradeexport_xml'] = array (
  'pluginname' => 'XML file',
  'xml:publish' => 'Publish XML grade export',
  'xml:view' => 'Use XML grade export',
  'useridnumberwarning' => 'User\'s without an ID number are excluded from the XML export as they cannot be imported',
);