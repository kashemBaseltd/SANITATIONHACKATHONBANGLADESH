<?php $this->cache['en']['repository_s3'] = array (
  'access_key' => 'Access key',
  'configplugin' => 'Amazon S3 settings',
  'needaccesskey' => 'Access key must be provided',
  'pluginname' => 'Amazon S3',
  'secret_key' => 'Secret key',
  's3:view' => 'View amazon s3 repository',
);