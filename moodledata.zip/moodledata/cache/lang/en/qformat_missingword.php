<?php $this->cache['en']['qformat_missingword'] = array (
  'pluginname' => 'Missing word format',
  'pluginname_help' => 'Missing word format enables questions to be imported via text file.',
  'pluginname_link' => 'Missing word format',
);