<?php $this->cache['en']['report_progress'] = array (
  'pluginname' => 'Activity completion',
  'page-report-progress-x' => 'Any activity completion report',
  'page-report-progress-index' => 'Activity completion report',
  'page-report-progress-user' => 'User activity completion report',
  'progress:view' => 'View activity completion reports',
);