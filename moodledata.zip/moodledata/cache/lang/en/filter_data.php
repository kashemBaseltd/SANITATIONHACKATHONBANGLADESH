<?php $this->cache['en']['filter_data'] = array (
  'filtername' => 'Database auto-linking',
);