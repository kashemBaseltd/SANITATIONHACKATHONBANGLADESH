<?php $this->cache['en']['quizaccess_numattempts'] = array (
  'attemptsallowedn' => 'Attempts allowed: {$a}',
  'pluginname' => 'Number of attempts quiz access rule',
);