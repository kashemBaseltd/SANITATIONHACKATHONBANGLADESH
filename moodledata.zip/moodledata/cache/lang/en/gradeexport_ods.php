<?php $this->cache['en']['gradeexport_ods'] = array (
  'pluginname' => 'OpenDocument spreadsheet',
  'ods:publish' => 'Publish ODS grade export',
  'ods:view' => 'Use OpenDocument grade export',
);