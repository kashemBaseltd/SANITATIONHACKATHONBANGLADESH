<?php $this->cache['en']['qbehaviour_informationitem'] = array (
  'pluginname' => 'behaviour for information items',
  'seen' => 'Seen',
);