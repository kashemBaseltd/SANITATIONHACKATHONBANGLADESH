<?php $this->cache['en']['datafield_text'] = array (
  'pluginname' => 'Text input',
);