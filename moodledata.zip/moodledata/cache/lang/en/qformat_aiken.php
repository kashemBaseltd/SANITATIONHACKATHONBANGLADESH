<?php $this->cache['en']['qformat_aiken'] = array (
  'pluginname' => 'Aiken format',
  'pluginname_help' => 'This is a simple format for importing multiple choice questions from a text file.',
  'pluginname_link' => 'qformat/aiken',
);