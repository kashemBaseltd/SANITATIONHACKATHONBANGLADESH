<?php $this->cache['en']['datafield_file'] = array (
  'pluginname' => 'File',
);