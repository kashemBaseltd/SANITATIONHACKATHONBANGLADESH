<?php $this->cache['en']['block_private_files'] = array (
  'managemyfiles' => 'Manage my files',
  'pluginname' => 'My private files',
  'privatefiles' => 'Private files',
);