<?php $this->cache['en']['assignment_upload'] = array (
  'pluginname' => 'Upload',
);