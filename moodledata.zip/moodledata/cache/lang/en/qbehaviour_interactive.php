<?php $this->cache['en']['qbehaviour_interactive'] = array (
  'notcomplete' => 'Not complete',
  'pluginname' => 'Interactive with multiple tries',
  'triesremaining' => 'Tries remaining: {$a}',
  'tryagain' => 'Try again',
);