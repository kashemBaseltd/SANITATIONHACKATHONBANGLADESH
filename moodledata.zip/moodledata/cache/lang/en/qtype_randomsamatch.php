<?php $this->cache['en']['qtype_randomsamatch'] = array (
  'nosaincategory' => 'There are no short answer questions in the category that you chose \'{$a->catname}\'. Choose a different category, make some questions in this category.',
  'notenoughsaincategory' => 'There is/are only {$a->nosaquestions} short answer questions in the category that you chose \'{$a->catname}\'. Choose a different category, make some more questions in this category or reduce the amount of questions you\'ve selected.',
  'pluginname' => 'Random short-answer matching',
  'pluginname_help' => 'From the student perspective, this looks just like a matching question. The difference is that the list of names or statements (questions) for matching are drawn randomly from the short answer questions in the current category. There should be sufficient unused short answer questions in the category, otherwise an error message will be displayed.',
  'pluginname_link' => 'question/type/randomsamatch',
  'pluginnameadding' => 'Adding a Random short-answer matching question',
  'pluginnameediting' => 'Editing a Random short-answer matching question',
  'pluginnamesummary' => 'Like a Matching question, but created randomly from the short answer questions in a particular category.',
);