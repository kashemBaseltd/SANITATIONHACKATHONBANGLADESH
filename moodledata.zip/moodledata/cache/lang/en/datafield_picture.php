<?php $this->cache['en']['datafield_picture'] = array (
  'pluginname' => 'Picture',
);