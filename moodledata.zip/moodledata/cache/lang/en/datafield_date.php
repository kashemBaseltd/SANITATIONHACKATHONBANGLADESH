<?php $this->cache['en']['datafield_date'] = array (
  'pluginname' => 'Date',
);