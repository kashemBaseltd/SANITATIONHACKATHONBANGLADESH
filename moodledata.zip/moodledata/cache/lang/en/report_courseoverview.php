<?php $this->cache['en']['report_courseoverview'] = array (
  'courseoverview:view' => 'View course overview report',
  'pluginname' => 'Course overview',
);