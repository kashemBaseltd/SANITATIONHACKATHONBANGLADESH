<?php $this->cache['en']['gradeexport_xls'] = array (
  'pluginname' => 'Excel spreadsheet',
  'xls:publish' => 'Publish XLS grade export',
  'xls:view' => 'Use Excel grade export',
);