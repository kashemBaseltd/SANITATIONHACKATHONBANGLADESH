<?php $this->cache['en']['assignfeedback_comments'] = array (
  'default' => 'Enabled by default',
  'default_help' => 'If set, this feedback method will be enabled by default for all new assignments.',
  'enabled' => 'Feedback comments',
  'enabled_help' => 'If enabled, the marker can leave feedback comments for each submission. ',
  'pluginname' => 'Feedback comments',
);