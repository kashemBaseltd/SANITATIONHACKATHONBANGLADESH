<?php $this->cache['en']['filter_algebra'] = array (
  'filtername' => 'Algebra notation',
  'algebraicexpression' => 'Algebraic expression',
);