<?php $this->cache['en']['qtype_random'] = array (
  'configselectmanualquestions' => 'Can the random question type select a manually graded question when it is making its random choice of a question from a category?',
  'includingsubcategories' => 'Including subcategories',
  'pluginname' => 'Random',
  'pluginname_help' => 'A random question is not a question type as such, but is a way of inserting a randomly-chosen question from a specified category into an activity.',
  'pluginnameediting' => 'Editing a random question',
  'randomqname' => 'Random ({$a})',
  'randomqplusname' => 'Random ({$a} and sub-categories)',
  'selectedby' => '{$a->questionname} selected by {$a->randomname}',
  'selectmanualquestions' => 'Random questions can use manually graded questions',
);