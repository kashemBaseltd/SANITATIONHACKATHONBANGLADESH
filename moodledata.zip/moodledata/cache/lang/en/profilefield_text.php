<?php $this->cache['en']['profilefield_text'] = array (
  'pluginname' => 'Text input',
);