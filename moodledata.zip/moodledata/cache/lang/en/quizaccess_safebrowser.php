<?php $this->cache['en']['quizaccess_safebrowser'] = array (
  'pluginname' => 'Safe Exam Browser quiz access rule',
  'requiresafeexambrowser' => 'Require the use of Safe Exam Browser',
  'safebrowsererror' => 'This quiz has been set up so that it may only be attempted using the Safe Exam Browser. You cannot attempt it from this web browser.',
  'safebrowsernotice' => 'This quiz has been configured so that students may only attempt it using the Safe Exam Browser.',
);