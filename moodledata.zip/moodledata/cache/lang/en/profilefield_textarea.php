<?php $this->cache['en']['profilefield_textarea'] = array (
  'pluginname' => 'Text area',
);