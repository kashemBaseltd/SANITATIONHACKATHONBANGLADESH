<?php $this->cache['en']['auth_webservice'] = array (
  'auth_webservicedescription' => 'This authentication method should be used for accounts that are exclusively for use by web service clients.',
  'pluginname' => 'Web services authentication',
);