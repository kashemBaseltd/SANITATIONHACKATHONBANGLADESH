<?php $this->cache['en']['block_comments'] = array (
  'pluginname' => 'Comments',
);