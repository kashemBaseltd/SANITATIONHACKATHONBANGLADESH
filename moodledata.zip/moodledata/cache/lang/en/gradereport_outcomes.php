<?php $this->cache['en']['gradereport_outcomes'] = array (
  'addoutcome' => 'Add an outcome',
  'courseoutcomes' => 'Course outcomes',
  'coursespecoutcome' => 'Course outcomes',
  'pluginname' => 'Outcomes report',
  'outcomes:view' => 'View the outcomes report',
  'usedgradeitem' => 'Number of grade items',
);