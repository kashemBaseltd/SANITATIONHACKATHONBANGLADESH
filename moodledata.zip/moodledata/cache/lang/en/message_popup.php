<?php $this->cache['en']['message_popup'] = array (
  'pluginname' => 'Popup notification',
);