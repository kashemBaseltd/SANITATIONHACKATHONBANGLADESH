<?php $this->cache['en']['report_participation'] = array (
  'participation:view' => 'View course participation report',
  'page-report-participation-x' => 'Any participation report',
  'page-report-participation-index' => 'Course participation report',
  'pluginname' => 'Course participation',
);