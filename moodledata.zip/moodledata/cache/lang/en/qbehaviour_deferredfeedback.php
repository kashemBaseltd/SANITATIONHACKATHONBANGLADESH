<?php $this->cache['en']['qbehaviour_deferredfeedback'] = array (
  'pluginname' => 'Deferred feedback',
);