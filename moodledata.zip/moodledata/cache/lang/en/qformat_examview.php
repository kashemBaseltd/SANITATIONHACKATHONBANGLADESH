<?php $this->cache['en']['qformat_examview'] = array (
  'pluginname' => 'Examview',
  'pluginname_help' => 'Examview format enables the import of questions from Examview 4 XML files. For newer versions of Examview, Blackboard format may be used.',
);