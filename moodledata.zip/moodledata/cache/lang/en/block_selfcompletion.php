<?php $this->cache['en']['block_selfcompletion'] = array (
  'alreadyselfcompleted' => 'You have already marked yourself as complete in this course',
  'completecourse' => 'Complete course',
  'pluginname' => 'Self completion',
  'selfcompletionnotenabled' => 'The self completion criteria has not been enabled for this course',
);