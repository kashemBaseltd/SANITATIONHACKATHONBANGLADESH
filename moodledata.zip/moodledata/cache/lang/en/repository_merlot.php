<?php $this->cache['en']['repository_merlot'] = array (
  'configplugin' => 'Merlot.org configuration',
  'licensekey' => 'License key',
  'pluginname_help' => 'Merlot.org',
  'pluginname' => 'Merlot.org',
  'merlot:view' => 'View the Merlot repository',
);