<?php $this->cache['en']['qformat_blackboard'] = array (
  'defaultname' => 'Imported question {$a}',
  'importnotext' => 'Missing question text in XML file',
  'notenoughtsubans' => 'Unable to import matching question \'{$a}\' because a matching question must comprise at least two questions and three answers.',
  'pluginname' => 'Blackboard',
  'pluginname_help' => 'Blackboard format enables questions saved in the Blackboard version 5 "POOL" type export format to be imported.',
);