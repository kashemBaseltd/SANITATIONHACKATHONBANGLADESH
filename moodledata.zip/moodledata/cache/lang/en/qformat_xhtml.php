<?php $this->cache['en']['qformat_xhtml'] = array (
  'pluginname' => 'XHTML format',
  'pluginname_help' => 'XHTML format enables all questions in the category to be exported to a single page of strict XHTML for possible use in another application.',
  'pluginname_link' => 'qformat/xhtml',
);