<?php $this->cache['en']['qbehaviour_interactivecountback'] = array (
  'pluginname' => 'Interactive with multiple tries (credit for earlier tries)',
);