<?php $this->cache['en']['datafield_url'] = array (
  'pluginname' => 'URL',
);