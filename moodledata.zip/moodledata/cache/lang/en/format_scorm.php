<?php $this->cache['en']['format_scorm'] = array (
  'sectionname' => 'SCORM',
  'pluginname' => 'SCORM format',
);