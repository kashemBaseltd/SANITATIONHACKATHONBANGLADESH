<?php $this->cache['en']['assignment_uploadsingle'] = array (
  'pluginname' => 'Upload single',
);