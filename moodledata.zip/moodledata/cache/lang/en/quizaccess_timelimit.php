<?php $this->cache['en']['quizaccess_timelimit'] = array (
  'pluginname' => 'Time limit quiz access rule',
  'quiztimelimit' => 'Time limit: {$a}',
);