<?php $this->cache['en']['gradereport_overview'] = array (
  'pluginname' => 'Overview report',
  'overview:view' => 'View the overview report',
);