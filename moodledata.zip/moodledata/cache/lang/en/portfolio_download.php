<?php $this->cache['en']['portfolio_download'] = array (
  'downloadfile' => 'Download your portfolio export file',
  'downloading' => 'Downloading ...',
  'pluginname' => 'File download',
);