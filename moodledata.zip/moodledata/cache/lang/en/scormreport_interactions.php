<?php $this->cache['en']['scormreport_interactions'] = array (
  'pluginname' => 'Interactions Report',
  'questionx' => 'Question {$a}',
  'responsex' => 'Response {$a}',
  'rightanswerx' => 'Right answer {$a}',
  'summaryofquestiontext' => 'Summary of question',
  'summaryofresponse' => 'Summary of responses',
  'summaryofrightanswer' => 'Summary of right answer',
);