<?php $this->cache['en']['assignment_online'] = array (
  'pluginname' => 'Online',
);