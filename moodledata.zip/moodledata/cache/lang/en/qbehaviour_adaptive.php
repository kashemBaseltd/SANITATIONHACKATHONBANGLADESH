<?php $this->cache['en']['qbehaviour_adaptive'] = array (
  'disregardedwithoutpenalty' => 'The submission was invalid, and has been disregarded without penalty.',
  'gradingdetails' => 'Marks for this submission: {$a->raw}/{$a->max}.',
  'gradingdetailsadjustment' => 'Accounting for previous tries, this gives <strong>{$a->cur}/{$a->max}</strong>.',
  'gradingdetailspenalty' => 'This submission attracted a penalty of {$a}.',
  'gradingdetailspenaltytotal' => 'Total penalties so far: {$a}.',
  'notcomplete' => 'Not complete',
  'pluginname' => 'Adaptive mode',
);