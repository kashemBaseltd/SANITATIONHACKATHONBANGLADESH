<?php $this->cache['en']['block_course_summary'] = array (
  'coursesummary' => 'Course summary',
  'pluginname' => 'Course/Site description',
);