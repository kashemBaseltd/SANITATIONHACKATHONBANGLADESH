<?php $this->cache['en']['qformat_blackboard_six'] = array (
  'defaultname' => 'Imported question {$a}',
  'errormanifest' => 'Error while parsing the IMS manifest document',
  'importnotext' => 'Missing question text in XML file',
  'filenothandled' => 'This archive contains reference to a file material {$a} which is not currently handled by import',
  'imagenotfound' => 'Image file with path {$a} was not found in the import.',
  'notenoughtsubans' => 'Unable to import matching question \'{$a}\' because a matching question must comprise at least two questions and three answers.',
  'pluginname' => 'Blackboard V6+',
  'pluginname_help' => 'Blackboard V6+ format enables questions saved in all Blackboard export formats to be imported via a dat or zip file. For zip files, images import is supported.',
  'unhandledpresblock' => 'Unhandled presentation block',
  'unknownorunhandledtype' => 'Unknown or unhandled question type: {$a}',
);