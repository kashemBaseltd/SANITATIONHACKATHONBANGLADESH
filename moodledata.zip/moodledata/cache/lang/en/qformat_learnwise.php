<?php $this->cache['en']['qformat_learnwise'] = array (
  'pluginname' => 'Learnwise format',
  'plugidnname_help' => 'This format enables the import of multiple choice questions saved in Learnwise\'s XML format.',
);