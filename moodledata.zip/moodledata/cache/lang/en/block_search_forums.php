<?php $this->cache['en']['block_search_forums'] = array (
  'advancedsearch' => 'Advanced search',
  'pluginname' => 'Search forums',
);