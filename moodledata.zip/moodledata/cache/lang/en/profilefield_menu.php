<?php $this->cache['en']['profilefield_menu'] = array (
  'pluginname' => 'Menu of choices',
);