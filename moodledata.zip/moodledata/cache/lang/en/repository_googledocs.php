<?php $this->cache['en']['repository_googledocs'] = array (
  'clientid' => 'Client ID',
  'configplugin' => 'Configure Google Docs plugin',
  'googledocs:view' => 'View google docs repository',
  'oauthinfo' => '<p>To use this plugin, you must register your site with Google, as described in the documentation <a href="{$a->docsurl}">Google OAuth 2.0 setup</a>.</p><p>As part of the registration process, you will need to enter the following URL as \'Authorized Redirect URIs\':</p><p>{$a->callbackurl}</p>Once registered, you will be provided with a client ID and secret which can be used to configure all Google Docs and Picasa plugins.</p>',
  'oauth2upgrade_message_subject' => 'Important information regarding Google Docs repository plugin',
  'oauth2upgrade_message_content' => 'As part of the upgrade to Moodle 2.3, the Google Docs portfolio plugin has been disabled. To re-enable it, your Moodle site needs to be registered with Google, as described in the documentation {$a->docsurl}, in order to obtain a client ID and secret. The client ID and secret can then be used to configure all Google Docs and Picasa plugins.',
  'oauth2upgrade_message_small' => 'This plugin has been disabled, as it requires configuration as described in the documentation Google OAuth 2.0 setup.',
  'pluginname' => 'Google Docs',
  'secret' => 'Secret',
);