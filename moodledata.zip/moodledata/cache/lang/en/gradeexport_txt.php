<?php $this->cache['en']['gradeexport_txt'] = array (
  'pluginname' => 'Plain text file',
  'txt:publish' => 'Publish TXT grade export',
  'txt:view' => 'Use text grade export',
);