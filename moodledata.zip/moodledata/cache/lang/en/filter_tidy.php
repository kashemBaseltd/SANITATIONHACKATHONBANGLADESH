<?php $this->cache['en']['filter_tidy'] = array (
  'filtername' => 'HTML tidy',
);