<?php $this->cache['en']['qtype_missingtype'] = array (
  'answerno' => 'Answer {$a}',
  'cannotchangeamissingqtype' => 'You cannot make any changes to a question of a missing type.',
  'deletedquestion' => 'Missing question',
  'deletedquestiontext' => 'This question is missing. Unable to display anything.',
  'missingqtypewarning' => 'This question is of a type that is not currently installed on this system. You will not be able to do anything with this question.',
  'missing' => 'Question of a type that is not installed on this system',
  'pluginname' => 'Missing type',
  'pluginnameadding' => 'Adding a question of a type that is not installed on this system',
  'pluginnameediting' => 'Editing a question of a type that is not installed on this system',
  'warningmissingtype' => '<b>This question is of a type that has not been installed on your Moodle yet.<br />Please alert your Moodle administrator.</b>',
);