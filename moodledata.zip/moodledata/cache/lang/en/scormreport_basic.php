<?php $this->cache['en']['scormreport_basic'] = array (
  'pluginname' => 'Basic Report',
);