<?php $this->cache['en']['datapreset_imagegallery'] = array (
  'modulename' => 'Image gallery',
  'pluginname' => 'Image gallery',
);