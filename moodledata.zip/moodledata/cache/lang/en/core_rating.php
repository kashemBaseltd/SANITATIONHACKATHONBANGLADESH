<?php $this->cache['en']['core_rating'] = array (
  'aggregatetype' => 'Aggregate type',
  'aggregateavg' => 'Average of ratings',
  'aggregatecount' => 'Count of ratings',
  'aggregatemax' => 'Maximum rating',
  'aggregatemin' => 'Minimum rating',
  'aggregatenone' => 'No ratings',
  'aggregatesum' => 'Sum of ratings',
  'aggregatetype_help' => 'The aggregate type defines how ratings are combined to form the final grade in the gradebook.

* Average of ratings - The mean of all ratings
* Count of ratings - The number of rated items becomes the final grade. Note that the total cannot exceed the maximum grade for the activity.
* Maximum - The highest rating becomes the final grade
* Minimum - The smallest rating becomes the final grade
* Sum - All ratings are added together. Note that the total cannot exceed the maximum grade for the activity.

If "No ratings" is selected, then the activity will not appear in the gradebook.',
  'allowratings' => 'Allow items to be rated?',
  'allratingsforitem' => 'All submitted ratings',
  'capabilitychecknotavailable' => 'Capability check not available until activity is saved',
  'couldnotdeleteratings' => 'Sorry, that cannot be deleted as people have already rated it',
  'norate' => 'Rating of items not allowed!',
  'noratings' => 'No ratings submitted',
  'noviewanyrate' => 'You can only look at results for items that you made',
  'noviewrate' => 'You do not have the capability to view item ratings',
  'rate' => 'Rate',
  'ratepermissiondenied' => 'You do not have permission to rate this item',
  'rating' => 'Rating',
  'ratinginvalid' => 'Rating is invalid',
  'ratingtime' => 'Restrict ratings to items with dates in this range:',
  'ratings' => 'Ratings',
  'rolewarning' => 'Roles with permission to rate',
  'rolewarning_help' => 'To submit ratings users require the moodle/rating:rate capability and any module specific capabilities. Users assigned the following roles should be able to rate items. The list of roles may be amended via the permissions link in the settings block.',
);