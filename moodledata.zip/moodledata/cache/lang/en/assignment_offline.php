<?php $this->cache['en']['assignment_offline'] = array (
  'pluginname' => 'Offline',
);