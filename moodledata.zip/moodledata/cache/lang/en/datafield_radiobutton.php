<?php $this->cache['en']['datafield_radiobutton'] = array (
  'pluginname' => 'Radio button',
);