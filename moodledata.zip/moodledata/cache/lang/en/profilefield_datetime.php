<?php $this->cache['en']['profilefield_datetime'] = array (
  'currentdatedefault' => 'Check to use current date as default',
  'defaultdate' => 'Default date',
  'endyear' => 'End year',
  'notset' => 'Not set',
  'pluginname' => 'Date/Time',
  'specifydatedefault' => 'or specify a date',
  'startyearafterend' => 'The start year can\'t occur after the end year',
  'startyear' => 'Start year',
  'wanttime' => 'Include time?',
);