<?php $this->cache['en']['booktool_print'] = array (
  'pluginname' => 'Book printing',
  'printbook' => 'Print book',
  'printchapter' => 'Print this chapter',
  'printdate' => 'Date',
  'printedby' => 'Printed by',
  'print:print' => 'Print book',
);