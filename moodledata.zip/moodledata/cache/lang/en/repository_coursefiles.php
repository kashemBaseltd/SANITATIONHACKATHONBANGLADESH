<?php $this->cache['en']['repository_coursefiles'] = array (
  'configplugin' => 'Configuration for legacy course files repository',
  'emptyfilelist' => 'There are no files to show',
  'notitle' => 'notitle',
  'remember' => 'Remember me',
  'pluginname_help' => 'Legacy course files',
  'pluginname' => 'Legacy course files',
  'coursefiles:view' => 'Use course files repository plugin',
);