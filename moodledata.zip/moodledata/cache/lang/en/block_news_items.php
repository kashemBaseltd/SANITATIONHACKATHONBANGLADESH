<?php $this->cache['en']['block_news_items'] = array (
  'pluginname' => 'Latest news',
);