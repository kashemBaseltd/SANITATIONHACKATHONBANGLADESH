<?php $this->cache['en']['datafield_checkbox'] = array (
  'pluginname' => 'Checkbox',
);