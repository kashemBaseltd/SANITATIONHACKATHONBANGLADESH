<?php $this->cache['en']['repository_dropbox'] = array (
  'configplugin' => 'Dropbox configuration',
  'notitle' => 'notitle',
  'remember' => 'Remember me',
  'pluginname' => 'Dropbox',
  'apikey' => 'Dropbox API key',
  'dropbox' => 'Dropbox',
  'secret' => 'Dropbox secret',
  'instruction' => 'You can get your API Key and secret from <a href="http://www.dropbox.com/developers/apps">Dropbox developers</a>. When setting up your key please select "Full Dropbox" as the "Access level".',
  'cachelimit' => 'Cache limit',
  'cachelimit_info' => 'Enter the maximum size of files (in bytes) to be cached on server for Dropbox aliases/shortcuts. Cached files will be served when the source is no longer available. Empty value or zero mean caching of all files regardless of size.',
  'dropbox:view' => 'View a Dropbox folder',
  'logoutdesc' => '(Logout when you finish using Dropbox)',
);