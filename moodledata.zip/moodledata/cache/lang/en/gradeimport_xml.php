<?php $this->cache['en']['gradeimport_xml'] = array (
  'errbadxmlformat' => 'Error - bad XML format',
  'errduplicategradeidnumber' => 'Error - there are two grade items with idnumber \'{$a}\' in this course. This should be impossible.',
  'errduplicateidnumber' => 'Error - duplicate idnumber',
  'errincorrectgradeidnumber' => 'Error - idnumber \'{$a}\' from the import file does not match any grade item.',
  'errincorrectidnumber' => 'Error - incorrect idnumber',
  'errincorrectuseridnumber' => 'Error - idnumber \'{$a}\' from the import file does not match any user.',
  'error' => 'Errors occur',
  'fileurl' => 'Remote file URL',
  'pluginname' => 'XML file',
  'xml:publish' => 'Publish import grades from XML',
  'xml:view' => 'Import grades from XML',
);