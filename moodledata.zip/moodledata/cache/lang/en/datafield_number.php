<?php $this->cache['en']['datafield_number'] = array (
  'pluginname' => 'Number',
);