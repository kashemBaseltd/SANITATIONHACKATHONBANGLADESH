<?php $this->cache['en']['report_completion'] = array (
  'completion:view' => 'View course completion report',
  'completiondate' => 'Completion date',
  'page-report-completion-x' => 'Any completion report',
  'page-report-completion-index' => 'Course completion report',
  'page-report-completion-user' => 'User course completion report',
  'pluginname' => 'Course completion',
);