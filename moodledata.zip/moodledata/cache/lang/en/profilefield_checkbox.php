<?php $this->cache['en']['profilefield_checkbox'] = array (
  'pluginname' => 'Checkbox',
);