<?php $this->cache['bn']['assignsubmission_comments'] = array (
  'default' => 'Enabled by default',
  'default_help' => 'If set, this submission method will be enabled by default for all new assignments.',
  'enabled' => 'Submission comments',
  'enabled_help' => 'If enabled, students can leave comments on their own submission. This can be used to let students alert the marker about which files the master file is in cases of inter-linked files, for instance.
',
  'pluginname' => 'Submission comments',
);