<?php $this->cache['bn']['tool_unsuproles'] = array (
  'contextlevel' => 'Context level',
  'count' => 'Count',
  'confirmdelete' => 'Do you really want to delete all unsupported role assignments for role "{$a->role}" in context level "{$a->level}"?',
  'noprolbems' => 'No unsupported role assignments found.',
  'pluginname' => 'Unsupported role assignments',
);