<?php $this->cache['bn']['block_login'] = array (
  'pluginname' => 'লগইন',
);