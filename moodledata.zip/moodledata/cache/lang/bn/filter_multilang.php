<?php $this->cache['bn']['filter_multilang'] = array (
  'filtername' => 'Multi-Language Content',
);