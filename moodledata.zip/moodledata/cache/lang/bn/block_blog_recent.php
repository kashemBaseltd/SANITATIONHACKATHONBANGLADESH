<?php $this->cache['bn']['block_blog_recent'] = array (
  'norecentblogentries' => 'কোনো সাম্প্রতিক এন্ট্রি নেই',
  'numentriestodisplay' => 'প্রদর্শনের জন্য সাম্প্রতিক এন্ট্রির সংখ্যা',
  'pluginname' => 'সাম্প্রতিক ব্লগ এন্ট্রি',
  'recentinterval' => 'সময় এর বিরতি "সাম্প্রতিক" হিসাবে গন্য',
);