<?php $this->cache['bn']['report_loglive'] = array (
  'loglive:view' => 'View live logs',
  'pluginname' => 'লাইভ লগ',
  'livelogs' => 'আগের ঘন্টার সচল লগসমূহ',
);