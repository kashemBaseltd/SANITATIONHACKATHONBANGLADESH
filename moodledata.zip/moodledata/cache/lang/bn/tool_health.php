<?php $this->cache['bn']['tool_health'] = array (
  'healthnoproblemsfound' => 'কোন স্বাস্থ্য সমস্যা পাওয়া যায় নাই',
  'healthproblemsdetected' => 'স্বাস্থ্য সমস্যা সনাক্ত হয়েছে',
  'healthproblemsolution' => 'স্বাস্থ্য সমস্যার সমাধান',
  'healthreturntomain' => 'চালিয়ে যান',
  'healthsolution' => 'সমাধান',
  'pluginname' => 'স্বাস্থ্য কেন্দ্র',
);