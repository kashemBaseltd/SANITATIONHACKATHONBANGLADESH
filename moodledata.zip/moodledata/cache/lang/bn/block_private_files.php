<?php $this->cache['bn']['block_private_files'] = array (
  'managemyfiles' => 'আমার ফাইল ব্যবস্থাপনা',
  'pluginname' => 'ব্যবহারকারীর ব্যক্তিগত ফাইল',
  'privatefiles' => 'ব্যক্তিগত ফাইল',
);