<?php $this->cache['bn']['block_course_overview'] = array (
  'pluginname' => 'কোর্স এর সারসংক্ষেপ',
);