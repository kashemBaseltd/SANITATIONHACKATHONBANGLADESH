<?php $this->cache['bn']['block_online_users'] = array (
  'configtimetosee' => 'ব্যবহারকারী অনলাইনে না থাকা সময়ে কতক্ষন যাবৎ নিস্ক্রিয় আছেন তা মিনিটে গণনা',
  'online_users:viewlist' => 'অনলাইনে থাকা ব্যবহারকারীর তালিকা প্রদর্শন',
  'periodnminutes' => 'শেষ মিনিট {$a} ',
  'pluginname' => 'অনলাইন ব্যবহারকারী',
  'timetosee' => 'নিস্ক্রিয় থাকার পর অপসারন (মিনিট)',
);