<?php $this->cache['bn']['block_calendar_month'] = array (
  'pluginname' => 'ক্যালেন্ডার',
);