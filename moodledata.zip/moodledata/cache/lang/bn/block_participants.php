<?php $this->cache['bn']['block_participants'] = array (
  'pluginname' => 'ব্যাক্তিবর্গ',
);