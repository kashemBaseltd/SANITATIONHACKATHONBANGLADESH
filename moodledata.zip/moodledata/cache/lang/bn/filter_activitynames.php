<?php $this->cache['bn']['filter_activitynames'] = array (
  'filtername' => 'Activity names auto-linking',
);