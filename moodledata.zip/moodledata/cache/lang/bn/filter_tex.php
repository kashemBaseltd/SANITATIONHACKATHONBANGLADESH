<?php $this->cache['bn']['filter_tex'] = array (
  'filtername' => 'TeX notation',
  'source' => 'TeX source',
);