<?php $this->cache['bn']['workshopform_comments'] = array (
  'addmoredimensions' => '{$a} আরও দৃষ্টিভঙ্গির জন্য ফাঁকাস্থান',
  'dimensioncomment' => 'সমালোচনা',
  'dimensiondescription' => 'বর্ণনা',
  'dimensionnumber' => '{$a} দৃষ্টিভঙ্গি',
  'pluginname' => 'সমালোচনা',
);