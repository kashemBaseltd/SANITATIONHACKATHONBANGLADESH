<?php $this->cache['bn']['block_completionstatus'] = array (
  'completionprogressdetails' => 'কতখানি সম্পন্ন হয়েছে তার বিস্তারিত তথ্য',
  'criteriagroup' => 'বিশেষ বৈশিষ্ট সম্পন্ন গ্রুপ',
  'firstofsecond' => '{$a->first} of {$a->second}',
  'pluginname' => 'কোর্স কতখানি সম্পন্ন হয়েছে তার অবস্থা',
  'requirement' => 'আবশ্যকতা',
  'returntocourse' => 'Return to course',
);