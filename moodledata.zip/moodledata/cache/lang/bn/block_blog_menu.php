<?php $this->cache['bn']['block_blog_menu'] = array (
  'pluginname' => 'ব্লগ মেনু',
);