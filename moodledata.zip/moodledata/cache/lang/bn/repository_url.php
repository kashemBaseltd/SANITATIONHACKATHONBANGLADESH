<?php $this->cache['bn']['repository_url'] = array (
  'download' => 'Download',
  'rename' => 'Name',
  'pluginname' => 'URL downloader',
  'url' => 'URL',
  'url:view' => 'Use URL downloader in file picker',
  'validname' => 'You must provide a valid file name',
  'configplugin' => 'URL repository type configuration',
);