<?php $this->cache['bn']['block_comments'] = array (
  'pluginname' => 'মন্তব্য',
);