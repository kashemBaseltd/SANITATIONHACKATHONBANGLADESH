<?php $this->cache['bn']['report_log'] = array (
  'log:view' => 'কোর্স লগ প্রদর্শন',
  'log:viewtoday' => 'আজকের লগ প্রদর্শন',
  'logsformat' => 'Logs format',
  'page-report-log-x' => 'Any log report',
  'page-report-log-index' => 'Course log report',
  'page-report-log-user' => 'User course log report',
  'pluginname' => 'লাইভ লগ',
);