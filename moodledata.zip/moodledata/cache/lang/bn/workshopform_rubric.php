<?php $this->cache['bn']['workshopform_rubric'] = array (
  'addmoredimensions' => 'আরও {$a} শর্তের জন্য ফাঁকাস্থান',
  'configuration' => 'রুব্রিক কনফিগারেশন',
  'criteria' => 'শর্ত',
  'dimensiondescription' => 'বর্ণনা',
  'dimensionnumber' => 'শর্তাবলী {$a}',
  'layout' => 'রুব্রিক বহির্বিন্যাস',
  'layoutgrid' => 'গ্রিড',
  'layoutlist' => 'তালিকা',
  'levelgroup' => 'গ্রেড এবং সংজ্ঞার ধাপ',
  'levels' => 'ধাপ',
  'mustchooseone' => 'এই আইটেমসমূহ থেকে একটি আইটেম নির্বাচন করতে হবে',
  'pluginname' => 'রুব্রিক',
);