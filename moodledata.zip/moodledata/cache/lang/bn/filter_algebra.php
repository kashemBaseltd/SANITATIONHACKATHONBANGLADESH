<?php $this->cache['bn']['filter_algebra'] = array (
  'filtername' => 'Algebra notation',
  'algebraicexpression' => 'Algebraic expression',
);