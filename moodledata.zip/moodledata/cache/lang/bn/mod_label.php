<?php $this->cache['bn']['mod_label'] = array (
  'label:addinstance' => 'Add a new label',
  'labeltext' => 'লেবেলের লেখা',
  'modulename' => 'লেবেল',
  'modulename_help' => 'কোর্স পৃষ্ঠায় যে যে লিংকে কাজ করা হয় সেখানে এই লেবেল ব্যবহার করে লেখা ও চিত্র দেয়া যায়।',
  'modulename_link' => 'mod/label/view',
  'modulenameplural' => 'লেবেল',
  'pluginadministration' => 'লেবেল প্রশাসন',
  'pluginname' => 'লেবেল',
);