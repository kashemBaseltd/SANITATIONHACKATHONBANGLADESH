<?php $this->cache['bn']['block_messages'] = array (
  'pluginname' => 'Messages',
);