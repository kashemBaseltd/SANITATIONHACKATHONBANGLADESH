<?php $this->cache['bn']['tool_capability'] = array (
  'capabilitylabel' => 'Capability:',
  'capabilityreport' => 'Capability overview',
  'forroles' => 'For roles {$a}',
  'getreport' => 'Get the overview',
  'changeoverrides' => 'Change overrides in this context',
  'changeroles' => 'Change role definitions',
  'intro' => 'This report shows, for a particular capability, what permission that capability has in the definition of every role (or a selection of roles), and everywhere in the site where that capability is overridden.',
  'pluginname' => 'Capability overview',
  'reportforcapability' => 'Report for capability \'{$a}\'',
  'reportsettings' => 'Report settings',
  'roleslabel' => 'Roles:',
);