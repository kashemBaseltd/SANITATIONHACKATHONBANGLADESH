<?php $this->cache['bn']['block_feedback'] = array (
  'pluginname' => 'মন্তব্য',
  'feedback' => 'মন্তব্য',
  'missing_feedback_module' => 'মন্তব্য কার্যকলাপের মডিউলের উপর ব্লক করা নির্ভর করে, কিন্তু ঐ মডিউলটা এখন নাই!',
);