<?php $this->cache['bn']['block_admin_bookmarks'] = array (
  'pluginname' => 'প্রসাশন বুকমার্ক',
);