<?php $this->cache['bn']['filter_tidy'] = array (
  'filtername' => 'HTML tidy',
);