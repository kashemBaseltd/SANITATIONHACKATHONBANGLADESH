<?php $this->cache['bn']['block_site_main_menu'] = array (
  'pluginname' => 'প্রধান মেনু',
);