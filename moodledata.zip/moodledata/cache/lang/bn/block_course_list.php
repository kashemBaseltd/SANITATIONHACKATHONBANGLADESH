<?php $this->cache['bn']['block_course_list'] = array (
  'adminview' => 'প্রসাশনিক ভিউ',
  'allcourses' => 'সব কোর্সে প্রসাশনিক ব্যবহারকারী',
  'configadminview' => 'কোর্স তালিকা ব্লকে প্রসাশন কি দেখা উচিত?',
  'confighideallcourseslink' => 'ব্লকের একদম উপরে "সব কোর্স" এর লিঙ্ক আড়াল। লিঙ্ক আড়াল করলে প্রসাশনের ভিউতে কোনো প্রভাব পড়েনা',
  'hideallcourseslink' => 'সব কোর্সের লিঙ্ক আড়াল',
  'owncourses' => 'প্রসাশনিক ব্যবহারকারী নিজের কোর্স দেখতে পায়',
  'pluginname' => 'কোর্সের তালিকা',
);