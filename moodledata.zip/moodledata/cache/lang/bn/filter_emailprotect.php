<?php $this->cache['bn']['filter_emailprotect'] = array (
  'filtername' => 'Email protection',
);