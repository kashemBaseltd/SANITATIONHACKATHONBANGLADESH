<?php $this->cache['bn']['block_activity_modules'] = array (
  'pluginname' => 'কার্যকলাপ',
);