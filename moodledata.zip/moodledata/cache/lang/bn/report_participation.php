<?php $this->cache['bn']['report_participation'] = array (
  'participation:view' => 'কোর্সে অংশগ্রহণের প্রতিবেদন প্রদর্শন',
  'page-report-participation-x' => 'Any participation report',
  'page-report-participation-index' => 'Course participation report',
  'pluginname' => 'কোর্সে অংশগ্রহণ',
);