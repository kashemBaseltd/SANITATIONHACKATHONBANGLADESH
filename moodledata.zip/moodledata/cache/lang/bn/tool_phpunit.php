<?php $this->cache['bn']['tool_phpunit'] = array (
  'pluginname' => 'PHPUnit tests',
);