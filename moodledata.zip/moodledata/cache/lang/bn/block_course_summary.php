<?php $this->cache['bn']['block_course_summary'] = array (
  'coursesummary' => 'কোর্সের সারসংক্ষেপ',
  'pluginname' => 'কোর্স/সাইটের বর্ণনা',
);