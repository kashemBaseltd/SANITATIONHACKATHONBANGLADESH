<?php $this->cache['bn']['auth_imap'] = array (
  'auth_imapdescription' => 'এ পদ্ধতিতে IMAP সার্ভার দিয়ে ব্যবহারকারীর নাম ও পাসওয়ার্ড কার্যকর কিনা তা পরীক্ষা।',
  'auth_imaphost' => 'IMAP সার্ভার ঠিকানা। DNS নাম না করে IP নাম্বার ব্যবহার।',
  'auth_imaphost_key' => 'হোস্ট',
  'auth_imapchangepasswordurl_key' => 'পাসওয়ার্ড-পরিবর্তন URL',
  'auth_imapnotinstalled' => 'IMAP প্রমাণীকরণ ব্যবহার করতে পারেনা। PHP IMAP মডিউল ইনস্টল করা নাই।',
  'auth_imapport' => 'IMAP সার্ভার পোর্ট নম্বর। সাধারণত 143 অথবা 993 হয়।',
  'auth_imapport_key' => 'পোর্ট',
  'auth_imaptype' => 'IMAP ধরণের সার্ভার। IMAP সার্ভারে বিভিন্ন ধরণের প্রমাণীকরণ এবং সমঝোতাকরণ থাকতে পারে।',
  'auth_imaptype_key' => 'ধরণ',
  'pluginname' => 'IMAP সার্ভার',
);