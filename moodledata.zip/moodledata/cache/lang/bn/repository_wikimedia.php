<?php $this->cache['bn']['repository_wikimedia'] = array (
  'keyword' => 'Full text',
  'pluginname' => 'Wikimedia',
  'wikimedia:view' => 'View wikimedia repository',
  'configplugin' => 'Wikimedia repository type configuration',
);