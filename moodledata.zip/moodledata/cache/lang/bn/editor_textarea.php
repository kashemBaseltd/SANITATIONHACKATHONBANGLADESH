<?php $this->cache['bn']['editor_textarea'] = array (
  'pluginname' => 'Plain text area',
);