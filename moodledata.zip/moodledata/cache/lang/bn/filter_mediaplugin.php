<?php $this->cache['bn']['filter_mediaplugin'] = array (
  'fallbackaudio' => 'Audio link',
  'fallbackvideo' => 'Video link',
  'filtername' => 'Multimedia plugins',
);