<?php $this->cache['bn']['report_outline'] = array (
  'outline:view' => 'কোর্স প্রক্রিয়ার প্রতিবেদন প্রদর্শন',
  'page-report-outline-x' => 'Any outline report',
  'page-report-outline-index' => 'Course outline report',
  'page-report-outline-user' => 'User course outline report',
  'pluginname' => 'কোর্স প্রক্রিয়া',
);