<?php $this->cache['bn']['tool_replace'] = array (
  'disclaimer' => 'I understand the risks of this operation:',
  'pageheader' => 'Search and replace text throughout the whole database',
  'notifyfinished' => '...finished',
  'notifyrebuilding' => 'Rebuilding course cache...',
  'notimplemented' => 'Sorry, this feature is implemented only for MySQL and PostgreSQL databases.',
  'notsupported' => 'This script is not supported, always make complete backup before proceeding!<br />This operation can not be reverted!',
  'pluginname' => 'DB search and replace',
  'replacewith' => 'Replace with this string:',
  'replacewithhelp' => 'usually new server URL',
  'searchwholedb' => 'Search whole database for:',
  'searchwholedbhelp' => 'usually previous server URL',
);