<?php $this->cache['bn']['theme_nonzero'] = array (
  'pluginname' => 'Nonzero',
  'region-side-post' => 'ডান',
  'region-side-pre' => 'বাম',
  'choosereadme' => '<div class="clearfix"><div class="theme_screenshot"><h2>Nonzero</h2><img src="nonzero/pix/screenshot.jpg" /><h3>থীম আলোচনা ফোরাম:</h3><p><a href="http://moodle.org/mod/forum/view.php?id=46">http://moodle.org/mod/forum/view.php?id=46</a></p><h3>থীম ক্রেডিট</h3><p><a href="http://docs.moodle.org/en/Theme_credits">http://docs.moodle.org/en/Theme_credits</a></p><h3>থীম নথিবদ্ধকরণ:</h3><p><a href="http://docs.moodle.org/en/Themes">http://docs.moodle.org/en/Themes</a></p><h3>বাগ রিপোর্ট:</h3><p><a href="http://tracker.moodle.org">http://tracker.moodle.org</a></p></div><div class="theme_description"><h2>পরিচিতি</h2><p>Nonzero একটি ঐতিহ্যবাহী নয় এমন, তিন-কলাম, ফ্লুইড-প্রস্থ বিশিষ্ট মুডলের থীম। এটি ঐতিহ্যবাহী নয় কারন এটি একটি নতুন তিন-কলাম বহির্বিন্যাস ব্যবহার করে যা কিনা উভয় ব্লক কলামের বামে বিষয়বস্তু প্রদর্শন করে।<h2>Tweaks</h2><p>থীমটি বেস এবং ক্যানভাস এর উপর তৈরি হয়, Moodle কেন্দ্রে দুইটি প্যারেন্ট থীম সংযুক্ত হয়। যদি আপনি থীমটিকে পরিবর্তন করতে চান, সুপারিশ করা যাচ্ছে যে প্রথমে আপনি এটির প্রতিলিপি করবেন, তারপর আপনার পরিবর্তনের আগে পুনরায় নামকরণ করবেন। এটি আপনার স্বনির্বাচিত থীমকে ভবিষ্যতের মুডল হালনাগাদ দ্বারা এর উপরে লিখা থেকে প্রতিরোধ করা যাবে এবং কোন ভুল করলেও আপনার কাছে এখনও প্রকৃত ফাইল আছে। থীম পরিবর্তন করার জন্য আরও তথ্য পাওয়া যাবে <a href="http://docs.moodle.org/en/Theme">MoodleDocs</a>.</p><h3>লাইসেন্স</h3><p>এটি, এবং অন্যান্য সব থীম মুডল কেন্দ্রের সাথে সংযুক্ত, লাইসেন্সকৃত <a href="http://www.gnu.org/licenses/gpl.html">GNU সাধারণ পাবলিক লাইসেন্স</a>।</div></div>',
  'configtitle' => 'Nonzero সেটিং',
  'customcss' => 'স্বনির্ধারিত CSS',
  'customcssdesc' => 'এখানে যে কোন CSS দিলে তা প্রত্যেক পৃষ্ঠায় সহজেই থীমটি স্বনির্ধারণের অনুমতি দেয়।',
  'regionprewidth' => 'বাম কলামের প্রস্থ',
  'regionprewidthdesc' => 'এটি  বাম কলামে সংগঠিত ব্লক অঞ্চলের প্রস্থ নির্ধারন করে। ব্লগ বহির্বিন্যাস ব্যবহারের সময় কলামটি পৃষ্ঠার মাঝখানে প্রদর্শিত হয়',
  'regionpostwidth' => 'ডান কলামের প্রস্থ',
  'regionpostwidthdesc' => 'এটি  ডান কলামে সংগঠিত ব্লক অঞ্চলের প্রস্থ নির্ধারন করে।',
);