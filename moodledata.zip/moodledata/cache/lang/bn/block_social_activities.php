<?php $this->cache['bn']['block_social_activities'] = array (
  'pluginname' => 'সামাজিক কার্যকলাপ',
);