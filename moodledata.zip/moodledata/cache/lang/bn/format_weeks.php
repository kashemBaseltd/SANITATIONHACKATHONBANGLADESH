<?php $this->cache['bn']['format_weeks'] = array (
  'currentsection' => 'এই সপ্তাহ',
  'sectionname' => 'Week',
  'pluginname' => 'Weekly format',
  'section0name' => 'General',
  'page-course-view-weeks' => 'Any course main page in weeks format',
  'page-course-view-weeks-x' => 'Any course page in weeks format',
  'hidefromothers' => 'Hide week',
  'showfromothers' => 'Show week',
);