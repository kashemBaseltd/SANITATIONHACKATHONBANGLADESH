<?php $this->cache['bn']['auth_pop3'] = array (
  'auth_pop3description' => 'এ মেথড POP3 ব্যবহার করে পরীক্ষা করে যে ব্যবহারকারীর নাম ও পাসওয়ার্ড কার্যকর কিনা।',
  'auth_pop3host' => 'POP3 সার্ভার ঠিকানা। IP নাম্বার ব্যবহার করুন, DNS নাম নয়।',
  'auth_pop3host_key' => 'হোস্ট',
  'auth_pop3changepasswordurl_key' => 'পাসওয়ার্ড-পরিবর্তন URL',
  'auth_pop3mailbox' => 'সংযোগ দেয়ার মেইলবাক্সের নাম।  (সাধারণত INBOX)',
  'auth_pop3mailbox_key' => 'মেইলবাক্স',
  'auth_pop3notinstalled' => 'POP3 প্রমাণীকরণ ব্যবহার করতে পারেনা। PHP IMAP মডিউল ইনস্টল করা নেই।',
  'auth_pop3port' => 'সার্ভার পোর্ট (110 সর্বাধিক পরিচিত, 995 SSL এর জন্য পরিচিত)',
  'auth_pop3port_key' => 'পোর্ট',
  'auth_pop3type' => 'সার্ভারের ধরণ। যদি আপনার সার্ভার সার্টিফিকেট নিরাপত্তা ব্যবহাসর করে তবে, pop3cert নির্বাচন করুন।',
  'auth_pop3type_key' => 'ধরণ',
  'pluginname' => 'POP3 সার্ভার',
);