<?php $this->cache['bn']['report_stats'] = array (
  'pluginname' => 'কোর্সের পরিসংখ্যান',
  'page-report-stats-x' => 'Any statistics report',
  'page-report-stats-index' => 'Course statistics report',
  'page-report-stats-user' => 'User course statistics report',
  'stats:view' => 'কোর্সের পরিসংখ্যান প্রতিবেদন প্রদর্শন',
);