<?php $this->cache['bn']['filter_data'] = array (
  'filtername' => 'Database auto-linking',
);