<?php $this->cache['bn']['tool_timezoneimport'] = array (
  'configintrotimezones' => 'This page will search for new information about world timezones (including daylight savings time rules) and update your local database with this information.  These locations will be checked, in order: {$a} This procedure is generally very safe and can not break normal installations.  Do you wish to update your timezones now?',
  'importtimezones' => 'সময় অঞ্চলের সম্পূর্ণ তালিকা হালনাগাদ',
  'importtimezonescount' => '{$a->source} থেকে {$a->count} টি এন্ট্রি ইম্পোর্ট করা হয়েছে',
  'importtimezonesfailed' => 'কোন উৎস পাওয়া যায়নি! (খারাপ সংবাদ)',
  'pluginname' => 'Timezones updater',
  'updatetimezones' => 'সময় অঞ্চল হালনাগাদ',
);