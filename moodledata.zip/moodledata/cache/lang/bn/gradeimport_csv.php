<?php $this->cache['bn']['gradeimport_csv'] = array (
  'csv:view' => 'Import grades from CSV',
  'pluginname' => 'CSV file',
);