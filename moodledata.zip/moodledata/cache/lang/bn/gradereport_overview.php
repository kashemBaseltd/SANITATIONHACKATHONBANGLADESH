<?php $this->cache['bn']['gradereport_overview'] = array (
  'pluginname' => 'Overview report',
  'overview:view' => 'View the overview report',
);