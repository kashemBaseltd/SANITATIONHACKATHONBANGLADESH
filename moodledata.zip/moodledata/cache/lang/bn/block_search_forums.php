<?php $this->cache['bn']['block_search_forums'] = array (
  'advancedsearch' => 'উচ্চ পর্যায়ের অনুসন্ধান',
  'pluginname' => 'অনুসন্ধান করার ফোরাম',
);