<?php $this->cache['bn']['block_news_items'] = array (
  'pluginname' => 'সর্বশেষ সংবাদ',
);