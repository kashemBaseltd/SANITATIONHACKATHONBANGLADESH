<?php $this->cache['bn']['block_html'] = array (
  'configcontent' => 'বিষয়বস্তু',
  'configtitle' => 'শিরোনাম ব্লক',
  'leaveblanktohide' => 'শিরোনাম আড়াল করতে এটা খালি রাখুন',
  'newhtmlblock' => '(নতুন HTML ব্লক)',
  'pluginname' => 'HTML',
);