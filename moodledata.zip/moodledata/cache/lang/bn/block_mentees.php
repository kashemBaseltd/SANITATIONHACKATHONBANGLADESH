<?php $this->cache['bn']['block_mentees'] = array (
  'configtitle' => 'শিরোনাম ব্লক',
  'configtitleblankhides' => 'শিরোনাম ব্লক (ফাঁকা রাখা হলে কোনো শিরোনাম থাকবে না)',
  'leaveblanktohide' => 'শিরোনাম আড়াল করতে ফাঁকা রাখুন',
  'newmenteesblock' => '(নতুন মেন্টিস ব্লক)',
  'pluginname' => 'মেন্টিস',
);