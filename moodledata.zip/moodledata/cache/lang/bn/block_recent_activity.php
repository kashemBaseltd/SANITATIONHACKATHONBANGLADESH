<?php $this->cache['bn']['block_recent_activity'] = array (
  'pluginname' => 'সাম্প্রতিক কার্যকলাপ',
);