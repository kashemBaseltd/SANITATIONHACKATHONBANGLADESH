<?php $this->cache['bn']['gradereport_user'] = array (
  'pluginname' => 'User report',
  'user:view' => 'View your own grade report',
);