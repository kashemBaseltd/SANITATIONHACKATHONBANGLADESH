<?php $this->cache['bn']['auth_webservice'] = array (
  'auth_webservicedescription' => 'অ্যাকাউন্টে ব্যবহারের জন্য প্রমাণীকরণ প্রক্রিয়া শুধুমাত্র ওয়েব সার্ভিস ক্লায়েন্ট কর্তৃক ব্যবহারের জন্য।',
  'pluginname' => 'ওয়েব সার্ভিস প্রমাণীকরণ',
);