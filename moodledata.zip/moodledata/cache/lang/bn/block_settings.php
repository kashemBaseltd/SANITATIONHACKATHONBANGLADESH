<?php $this->cache['bn']['block_settings'] = array (
  'enabledock' => 'ব্লক ডক করা অনুমোদন',
  'pluginname' => 'সেটিং',
);