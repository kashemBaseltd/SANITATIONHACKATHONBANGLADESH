<?php $this->cache['bn']['block_blog_tags'] = array (
  'pluginname' => 'ব্লগ ট্যাগ',
);