<?php $this->cache['bn']['filter_glossary'] = array (
  'filtername' => 'Glossary auto-linking',
);