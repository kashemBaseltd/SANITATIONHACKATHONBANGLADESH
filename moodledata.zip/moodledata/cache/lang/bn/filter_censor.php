<?php $this->cache['bn']['filter_censor'] = array (
  'badwords' => 'shit,fucked,fucker,fuck,dickhead,dick,cockhead,cock,cunt,asshole,arsehole,prick,bitch,jism,whore,slut,wanker,wank,bastard,dildo,masturbate,orgasm,penis,nigger,pussy,vagina',
  'filtername' => 'Word censorship',
);