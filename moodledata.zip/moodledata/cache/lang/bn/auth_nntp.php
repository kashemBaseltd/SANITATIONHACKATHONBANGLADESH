<?php $this->cache['bn']['auth_nntp'] = array (
  'auth_nntpdescription' => 'এ পদ্ধতি ব্যবহারকারীর নাম ও পাসওয়ার্ড কার্যকর কিনা তা পরীক্ষা করতে NNTP ব্যবহার করে। ',
  'auth_nntphost' => 'NNTP সার্ভার ঠিকানা। IP নাম্বার ব্যবহার করুন, DNS নাম নয়।',
  'auth_nntphost_key' => 'হোস্ট',
  'auth_nntpchangepasswordurl_key' => 'পাসওয়ার্ড-পরিবর্তন URL',
  'auth_nntpnotinstalled' => 'NNTP প্রমাণীকরণ ব্যবহার করতে পারেনা। PHP IMAP মডিউল ইনস্টল করা নেই।',
  'auth_nntpport' => 'সার্ভার পোর্ট (119 সর্বাধিক পরিচিত)',
  'auth_nntpport_key' => 'পোর্ট',
  'pluginname' => 'NNTP সার্ভার',
);