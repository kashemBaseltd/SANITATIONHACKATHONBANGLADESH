<?php $this->cache['bn']['auth_pam'] = array (
  'auth_pamdescription' => 'এ পদ্ধতিতে স্থানীয় ব্যবহারকারী নামে প্রবেশ করতে PAM। এ মডিউল ব্যবহার করতে <a href="http://www.math.ohio-state.edu/~ccunning/pam_auth/">PHP4 PAM Authentication</a> ইনস্টল করতে হবে।',
  'auth_passwordisexpired' => 'পাসওয়ার্ড এর মেয়াদ শেষ। আপনি কি এখন পাসওয়ার্ড পরিবর্তন করতে চান?',
  'auth_passwordwillexpire' => '{$a} দিনের মধ্যে পাসওয়ার্ড এর মেয়াদ শেষ হয়ে যাবে। আপনি কি এখন পাসওয়ার্ড পরিবর্তন করতে চান?',
  'pluginname' => 'PAM (Pluggable Authentication Modules)',
);